class BlockedNumber {
  final String number;
  final DateTime blockedAt;

  BlockedNumber({
    required this.number,
    required this.blockedAt,
  });
}
